# Eddie Kubit
### CSE 5544 Lab 3
### Jian Chen, Tu-Th 11:10

<hr/>

**In Lab 2, I used d3, so my implementation of Lab 3 is done with bare bones Javascript and SVG** 

### Installation

#### VSCode
#### LiveServer Extension on VSCode

Once unzipped, navigate to the base directory unzipped in VSCode. Open `lab3.kubit.7.html` in the editor, and click the "Go Live" button in the bottom left corner of the VSCode UI (this button should appear once the Live Server Extension is installed). This should open the html file in a browser window. If a directory is opened in the browser window, navigate to the file or the directory where the file is stored. This will show the html file with all of the required scatter plots. 

*Note - radii of points are scaled up by a factor of 2 for visibility. The uncertainty is relative, so this is not a problem*