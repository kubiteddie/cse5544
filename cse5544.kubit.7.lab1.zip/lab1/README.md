# Eddie Kubit
### CSE 5544 Lab 1
### Jian Chen, Tu-Th 11:10

<hr>

**Running Instructions**

After unzipping the submission file to the default created directory, make sure that the files `cse5544.kubit.7.lab1.html` and `styles.css` are located in the lab1 subdirectory together. Then, click on `cse5544.kubit.7.lab1.html` to open the html file in a web browser. This file will have labeled sections for each of the 4 graphs in the assignment.